﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ModderDLL.Basic
{
    /// <summary>
    /// 一个用来随时修改游戏合成表的实例
    /// 
    /// </summary>
    public class RecipeMethod:ILoadable
    {
        private MethodInfo Recipe_set_Disable;
        private MethodInfo Recipe_set_RecipeIndex;
        private ConstructorInfo Recipe_Constructor;
        /// <summary>
        /// 将合成禁用
        /// </summary>
        /// <param name="recipe">要禁用的合成</param>
        /// <param name="disable">true是禁用,false是启用</param>
        /// <returns>成功设置:true，否则:false，如果一直返回false，可能是炸了</returns>
        public bool Disable(Recipe recipe!!, bool disable)
        {
            if (Recipe_set_Disable is null)
            {
                return false;
            }
            Recipe_set_Disable.Invoke(recipe, new object[] { disable });
            return true;
        }
        /// <summary>
        /// 临时注册一个合成
        /// </summary>
        /// <param name="recipe"></param>
        /// <returns></returns>
        public bool Register(Recipe recipe!!)
        {
            if(Recipe_Constructor is null)
            {
                return false;
            }
            try
            {
                if (Main.recipe.IndexInRange(recipe.RecipeIndex) && Main.recipe[recipe.RecipeIndex] == recipe)
                {
                    return false;
                }
                if (recipe.requiredTile.Contains(TileID.Bottles))
                {
                    recipe.AddConsumeItemCallback(Recipe.ConsumptionRules.Alchemy);
                }
                if (Recipe.numRecipes >= Recipe.maxRecipes)
                {
                    Recipe.maxRecipes += 500;
                    Array.Resize(ref Main.recipe, Recipe.maxRecipes);
                    Array.Resize(ref Main.availableRecipe, Recipe.maxRecipes);
                    Array.Resize(ref Main.availableRecipeY, Recipe.maxRecipes);
                    for (int i = Recipe.numRecipes; i < Recipe.maxRecipes; i++)
                    {
                        Main.recipe[i] = (Recipe)Recipe_Constructor.Invoke(new object[] { null });
                        Main.availableRecipeY[i] = 65f * i;
                    }
                }
                Main.recipe[Recipe.numRecipes] = recipe;
                Recipe_set_RecipeIndex.Invoke(recipe, new object[] { Recipe.numRecipes });
                Recipe.numRecipes++;
                FieldInfo FirstRecipeForItem = typeof(RecipeLoader).GetField("FirstRecipeForItem", BindingFlags.Static | BindingFlags.NonPublic);
                Recipe[] recipes = (Recipe[])FirstRecipeForItem.GetValue(null);
                if (recipes[recipe.createItem.type] == null)
                {
                    recipes[recipe.createItem.type] = recipe;
                }
                FirstRecipeForItem.SetValue(null, recipes);
                return true;
            }
            catch(Exception e)
            {
                ModderDLL.Instance.Logger.Error(e);
                return false;
            }
        }
        /// <summary>
        /// 由tml调用，不该被你使用
        /// </summary>
        /// <param name="mod"></param>
        public void Load(Mod mod)
        {
            try
            {
                Recipe_set_Disable = typeof(Recipe).GetMethod("set_" + nameof(Recipe.Disabled), BindingFlags.Instance | BindingFlags.NonPublic);
                if(Recipe_set_Disable is null)
                {
                    throw new Exception(nameof(Recipe.Disabled) + " is not found");
                }
                Recipe_set_RecipeIndex = typeof(Recipe).GetMethod("set_" + nameof(Recipe.RecipeIndex), BindingFlags.Instance | BindingFlags.NonPublic);
                if (Recipe_set_Disable is null)
                {
                    throw new Exception(nameof(Recipe.RecipeIndex) + " is not found");
                }
                var cs = typeof(Recipe).GetConstructors(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
                foreach (var c in cs)
                {
                    if(c.GetParameters().Length > 0)
                    {
                        Recipe_Constructor = c;
                        break;
                    }
                }
                if (Recipe_Constructor is null)
                {
                    throw new Exception(nameof(Recipe) + "'s constructors is not found");
                }
            }
            catch(Exception ex)
            {
                ModderDLL.Instance.Logger.Error(ex);
            }
        }
        /// <summary>
        /// 由tml调用，不该被你使用
        /// </summary>
        public void Unload()
        {
            Recipe_set_Disable = null;
            Recipe_set_RecipeIndex = null;
            Recipe_Constructor = null;
        }
        /// <summary>
        /// 指示这玩意炸了没，返回true表示炸了
        /// </summary>
        public bool IsAvailable => Recipe_set_Disable is null || Recipe_set_RecipeIndex is null || Recipe_Constructor is null;
    }
}
