﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Terraria.ModLoader.Core;
using Terraria.ModLoader.UI;

namespace ModderDLL.Advanced
{
    /// <summary>
    /// 一个和Mod有关的实例，提供一些和Mod有关的功能支持
    /// </summary>
    public class ModMethod : ILoadable
    {
        /// <summary>
        /// 由tml调用，不该被你使用
        /// </summary>
        /// <param name="mod"></param>
        public void Load(Mod mod)
        {
        }
        /// <summary>
        /// 由tml调用，不该被你使用
        /// </summary>
        public void Unload()
        {
        }
        /// <summary>
        /// 获取mod的文件
        /// 警告:这不该被调用！
        /// 仔细想想你真的需要用它吗？
        /// </summary>
        /// <param name="mod"></param>
        /// <exception cref="UnauthorizedException"></exception>
        /// <returns></returns>
        public static TmodFile GetFiles(Mod mod!!)
        {
            if (ModderDLL.CanUseAll)
            {
                throw new UnauthorizedException();
            }
            return (TmodFile)mod.GetType().GetField("File", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(mod);
        }
        /// <summary>
        /// 
        /// 覆盖储存当前的mod.tmodfile
        /// 警告：这不该被调用！
        /// 仔细想想你真的需要用它吗?
        /// </summary>
        /// <param name="files"></param>
        /// <exception cref="UnauthorizedException"></exception>
        public static void SaveTmodFile(TmodFile files!!)
        {
            if (ModderDLL.CanUseAll)
            {
                throw new UnauthorizedException();
            }
            MethodInfo savemethod = typeof(TmodFile).GetMethod("Save", BindingFlags.Instance | BindingFlags.NonPublic);
            savemethod.Invoke(files, null);
        }
    }
}
