﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ReLogic.Content;
using System;
using System.Collections.Generic;
using System.Reflection;
using Terraria.Achievements;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.GameContent.UI.Chat;
using Terraria.GameContent.UI.Elements;
using Terraria.Localization;
using Terraria.UI;
using Terraria.UI.Chat;

namespace ModderDLL.Advanced
{
    /// <summary>
    /// 一个提供成就注册的实例，实现依赖On.Terraria.GameContent.UI.States.UIAchievementsMenu.InitializePage
    /// 再挂炸了不关我事
    /// 使用方法
    /// 1:通过ModLoader.TryGetMod("ModderDLL", out Mod mod)确认此工具mod已加载;
    /// 2:通过ModContent.GetInstance获取AchievementMethod实例;
    /// 3:通过AchievementMethod.Register(Mod mod, string name)将你的mod注册;
    /// 注意!
    /// 本实例不提供任何保存，因此你应当在你mod卸载之前保存你注册的ModAchievement
    /// 通过ModAchievement.GetWindow获得读取和修改的代理器
    /// </summary>
    public class AchievementMethod : ILoadable
    {
        internal Dictionary<string, ModAchievement> achievements;
        internal Dictionary<string, ModAchievementCondition> conditions;
        /// <summary>
        /// 申请访问一个ModAchievement
        /// </summary>
        /// <param name="vistor">申请者</param>
        /// <param name="mod">访问对象对象</param>
        /// <param name="modachievementname">成就注册名</param>
        /// <returns>存在目标且所有者允许访问，返回目标;其余为null</returns>
        /// <exception cref="Exception">你唬谁呢？自己申请访问自己？注册成功返回实例，人自己能保存的好着呢</exception>
        public ModAchievement ApplyeAccessModAchievement(Mod vistor!!, Mod mod!!, string modachievementname)
        {
            if (vistor == mod)
            {
                throw new Exception("你唬谁呢？自己申请访问自己？");
            }
            string key = mod.Name + "_" + modachievementname;
            if (achievements.TryGetValue(key, out ModAchievement ma))
            {
                if (ma.CanAccess(vistor))
                {
                    return ma;
                }
            }
            return null;
        }
        /// <summary>
        /// 申请访问一个ModAchievementCondition
        /// </summary>
        /// <param name="vistor">申请者</param>
        /// <param name="mod">访问对象对象</param>
        /// <param name="modachievementconditionname">条件注册名</param>
        /// <returns>存在目标且所有者允许访问，返回目标;其余为null</returns>
        /// <exception cref="Exception">你唬谁呢？自己申请访问自己？注册成功返回实例，人自己能保存的好着呢</exception>
        public ModAchievementCondition ApplyeAccessModAchievementCondition(Mod vistor!!, Mod mod!!, string modachievementconditionname)
        {
            if (vistor == mod)
            {
                throw new Exception("你唬谁呢？自己申请访问自己？");
            }
            string key = mod.Name + "_" + modachievementconditionname;
            if (conditions.TryGetValue(key, out ModAchievementCondition mac))
            {
                if (mac.CanAccess(vistor))
                {
                    return mac;
                }
            }
            return null;
        }
        /// <summary>
        /// 将ModAchievement注册
        /// 不注册不会显示
        /// </summary>
        /// <typeparam name="T">继承了ModAchievement的类</typeparam>
        /// <param name="mod">你的mod实例，不可以为null，会抛出异常</param>
        /// <param name="name">成就名，只是内部标注用，显示根据重写方法决定</param>
        /// <returns>注册成功返回被注册的实例，否则返回null</returns>
        public ModAchievement RegisterModAchievement<T>(Mod mod!!, string name) where T : ModAchievement
        {
            ModAchievement achievement = Activator.CreateInstance<T>();
            achievement.InnerSetDefaults(mod, name);
            if (achievements.TryAdd(achievement.InnerName, achievement))
            {
                achievement.Index = achievements.Count;
                Main.statusText = $"成就注册成功:{name}";
                return achievement;
            }
            Main.statusText = $"成就注册失败:{name}";
            return null;
        }
        /// <summary>
        /// 将ModAchievement注册
        /// 如果你想别的Mod能够查询你的成就条件
        /// 那你最好进行注册，同时条件完成时也将触发回调Mod.Call
        /// 不注册不影响使用，部分功能受限
        /// </summary>
        /// <typeparam name="T">继承了ModAchievementCondition的类</typeparam>
        /// <param name="mod">你的mod实例，不可以为null，会抛出异常</param>
        /// <param name="name">成就名，只是内部标注用，显示根据重写方法决定</param>
        /// <returns>注册成功返回被注册的实例，否则返回null</returns>
        public ModAchievementCondition RegisterModAchievementCondition<T>(Mod mod!!, string name) where T : ModAchievementCondition
        {
            ModAchievementCondition condition = Activator.CreateInstance<T>();
            condition.InnerSetDefaults(mod, name);
            if (conditions.TryAdd(condition.InnerName, condition))
            {
                Main.statusText = $"成就条件注册成功:{name}";
                return condition;
            }
            Main.statusText = $"成就条件注册失败:{name}";
            return null;
        }
        /// <summary>
        /// 由tml调用，不该被你使用
        /// </summary>
        /// <param name="mod"></param>
        public void Load(Mod mod)
        {
            achievements = new();
            conditions = new();
        }
        /// <summary>
        /// 由tml调用，不该被你使用
        /// </summary>
        public void Unload()
        {
            achievements = null;
            conditions = null;
        }
        private static readonly RasterizerState OverflowHiddenRasterizerState = new()
        {
            CullMode = 0,
            ScissorTestEnable = true
        };
        /// <summary>
        /// 一个抽象类，继承它并通过AchievementMethod.Register注册后在游戏中可见
        /// 完成时会触发回调Mod.Call，回调格式[ModderDLL.Instance,"ModAchievementCompleted",this]
        /// </summary>
        public abstract class ModAchievement
        {
            internal int Index;
            /// <summary>
            /// 这个ModAchievement来自哪个mod
            /// </summary>
            public Mod Mod { get; internal set; }
            /// <summary>
            /// 这个ModAchievement注册时使用的标注名
            /// </summary>
            public string Name { get; private set; }
            /// <summary>
            /// 成就的类型，我懒得扩展了，实际上可以不止那4种
            /// </summary>
            public AchievementCategory Category = default;
            /// <summary>
            /// 成就是否完成
            /// </summary>
            public bool IsCompleted;
            /// <summary>
            /// 成就进度条，用于显示成就进度
            /// </summary>
            public IAchievementTracker Tracker;
            /// <summary>
            /// 是否隐藏进度条
            /// </summary>
            public bool HideTracker;
            /// <summary>
            /// 当你使用非原版的两种进度条时被调用
            /// 你要在此表明进度条情况
            /// 前值为进度，后置为进度最大值
            /// </summary>
            /// <returns></returns>
            public virtual Tuple<decimal,decimal> GetCustomTrackerValue()
            {
                return Tuple.Create(0m, 0m);
            }
            internal string InnerName => Mod.Name + "_" + Name;
            internal void InnerSetDefaults(Mod mod, string name)
            {
                Mod = mod;
                Name = name;
                OnComplete += CallOwner;
                SetDefault();
            }
            /// <summary>
            /// 看什么看，没写过SetDeault吗？
            /// 干啥用的还要问？
            /// </summary>
            public virtual void SetDefault()
            {

            }
            /// <summary>
            /// 显示在描述栏内的文字，一般是一些中二文字，你也可以判断是否完成来提示如何完成他
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual TextSnippet[] GetDescription(int tick, bool isMouseHovering)
            {
                return new TextSnippet[] { new(InnerName + "_NoDescription") }; 
            }
            /// <summary>
            /// 显示在标题栏的文字，一般是成就名，你也可以未完成时隐藏
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual TextSnippet[] GetName(int tick, bool isMouseHovering)
            {
                return new TextSnippet[] { new(InnerName) };
            }
            /// <summary>
            /// 成就的图标，最重要的东西之一，不可以为null
            /// 我没写自动缩放，理论上你也不应该使用64*64大小每帧以外的规格
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public abstract Asset<Texture2D> GetAchievementIcon(int tick, bool isMouseHovering);
            /// <summary>
            /// 成就的图标的选帧，最重要的东西之一
            /// 记得配合GetAchievementIcon使用，如果超出或者不足我也不知道会咋样
            /// 正常应该返回(x,y,64,64)
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public abstract Rectangle GetAchievementIconFrame(int tick, bool isMouseHovering);
            /// <summary>
            /// 成就外边框，大小为72*72，也可以换，但我不推荐每帧都换
            /// 你可以给完成或者未完成两种不同的边框
            /// 不重新使用原版边框
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Asset<Texture2D> GetAchievementIconBorders(int tick, bool isMouseHovering)
            {
                return Main.Assets.Request<Texture2D>("Images/UI/Achievement_Borders");
            }
            /// <summary>
            /// 成就外框选帧，你是多闲的要整动态边框？
            /// 理论上应该是72*72的边框，写别的炸了别怪我
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Rectangle GetAchievementIconBordersFrame(int tick, bool isMouseHovering)
            {
                return new(0, 0, 72, 72);
            }
            /// <summary>
            /// 成就底部面板，我也不知道这玩意多大长什么样
            /// 如果你也不知道，建议别动
            /// 不重写使用原版底部面板
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Asset<Texture2D> GetPanelTopTexture(int tick, bool isMouseHovering)
            {
                return null;
            }
            /// <summary>
            /// 成就底部面板，我也不知道这玩意多大长什么样
            /// 如果你也不知道，建议别动
            /// 不重写使用原版上部面板
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <param name="large"></param>
            /// <returns></returns>
            public virtual Asset<Texture2D> GetPanelBottomTexture(int tick, bool isMouseHovering, bool large)
            {
                return null;
            }
            /// <summary>
            /// 虽然只有那4种成就类型，但是这个小图标你还是可以改的
            /// 别问我这玩意多大，我不知道
            /// 不重写使用原版
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Asset<Texture2D> GetCategoryTexture(int tick, bool isMouseHovering)
            {
                return null;
            }
            /// <summary>
            /// 给名字上色
            /// 如果你会用TextSnippet可以考虑返回白色
            /// 默认情况是未完成银色，完成金色，鼠标在上面时和白色平均（加亮）
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Color GetNameBaseColor(int tick, bool isMouseHovering)
            {
                return Color.Lerp(!IsCompleted ? Color.Silver : Color.Gold, Color.White, isMouseHovering ? 0.5f : 0f);
            }
            /// <summary>
            /// 给描述上色
            /// 如果你会用TextSnippet可以考虑返回白色
            /// 默认情况是未完成暗灰，完成银色，鼠标在上面时取白色
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Color GetDescriptionBaseColor(int tick, bool isMouseHovering)
            {
                return Color.Lerp(!IsCompleted ? Color.DarkGray : Color.Silver, Color.White, isMouseHovering ? 1f : 0f);
            }
            /// <summary>
            /// 貌似是给底部面板上色的参数，我也不清楚
            /// 默认情况是完成灰色，未完成白色
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <param name="toporbootom"></param>
            /// <returns></returns>
            public virtual Color GetPanenlBaseColor(int tick, bool isMouseHovering, bool toporbootom)
            {
                return isMouseHovering ? Color.White : Color.Gray;
            }
            /// <summary>
            /// 不知道干啥的，我也不清楚
            /// 默认情况是(20,32,71,204)
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Color GetBackgroundColor(int tick, bool isMouseHovering)
            {
                return isMouseHovering ? new Color(46, 60, 119) : (new Color(26, 40, 89) * 0.8f);
            }
            /// <summary>
            /// 不知道干啥的，我也不清楚
            /// 默认情况是(10,16,35,204)
            /// </summary>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual Color GetBorderColor(int tick, bool isMouseHovering)
            {
                return isMouseHovering ? new Color(20, 30, 56) : (new Color(13, 20, 44) * 0.8f);
            }
            /// <summary>
            /// 允许你自行启用滤镜,如果启用了滤镜，应当返回true
            /// 不用你自己spriteBatch.Begin,里面自带了
            /// 值得一提的是，由于滤镜的立即绘制
            /// 当你的成就处于列表上端或者下端但未完全展示的时候
            /// 不会进行切片
            /// </summary>
            /// <param name="drawTarget">当前绘制的对象</param>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual bool UseEffect(UseEffectDrawTarget drawTarget, int tick, bool isMouseHovering)
            {
                return false;
            }
            /// <summary>
            /// 它在UseEffect之前调用
            /// 如果返回false，那么对象不再绘制
            /// </summary>
            /// <param name="drawTarget"></param>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            /// <returns></returns>
            public virtual bool PreDraw(UseEffectDrawTarget drawTarget, int tick, bool isMouseHovering)
            {
                return true;
            }
            /// <summary>
            /// 它在目标绘制完成之后调用
            /// 即便UseEffect中启用了滤镜，也不会影响它
            /// 因为它在重启绘制之后调用
            /// </summary>
            /// <param name="drawTarget"></param>
            /// <param name="tick"></param>
            /// <param name="isMouseHovering"></param>
            public virtual void PostDraw(UseEffectDrawTarget drawTarget, int tick, bool isMouseHovering)
            {

            }
            internal static void CallOwner(ModAchievement modAchievement)
            {
                modAchievement.Mod.Call(new object[] { ModderDLL.Instance, "ModAchievementCompleted", modAchievement });
            }
            /// <summary>
            /// 以ModAchievement为参数的void委托
            /// </summary>
            /// <param name="modAchievement"></param>
            public delegate void MAEvent(ModAchievement modAchievement);
            /// <summary>
            /// 当完成时触发
            /// </summary>
            public event MAEvent OnComplete;
            /// <summary>
            /// 当注销时触发
            /// </summary>
            public event MAEvent OnCancel;
            /// <summary>
            /// 当有完成条件被触发时触发
            /// </summary>
            public event ModAchievementCondition.MACEvent OnConditionCompleted;
            internal Dictionary<string, ModAchievementCondition> _conditions = new();
            /// <summary>
            /// 成就的条件
            /// </summary>
            public IReadOnlyDictionary<string, ModAchievementCondition> Conditions => _conditions;
            /// <summary>
            /// 给成就添加条件
            /// </summary>
            /// <param name="condition"></param>
            /// <exception cref="ArgumentException"></exception>
            public void AddCondition(ModAchievementCondition condition)
            {
                if (_conditions.ContainsKey(condition.InnerName))
                {
                    throw new ArgumentException("This condition had registered for this achievement");
                }
                _conditions.Add(condition.InnerName, condition);
                condition.OnComplete += OnConditionCompleted;
                condition.OnComplete += StatisticsCompleted;
            }
            /// <summary>
            /// 给成就添加一批条件
            /// </summary>
            /// <param name="conditions"></param>
            public void AddConditions(params ModAchievementCondition[] conditions)
            {
                foreach(ModAchievementCondition condition in conditions)
                {
                    AddCondition(condition);
                }
            }
            /// <summary>
            /// 统计当前条件完成情况
            /// 读入初始化后一定要执行
            /// </summary>
            /// <param name="condition"></param>
            public void StatisticsCompleted(ModAchievementCondition condition)
            {
                bool flag = true;
                foreach (ModAchievementCondition c in _conditions.Values)
                {
                    if (!c.IsCompleted)
                    {
                        flag = false;
                        break;
                    }
                }
                if (!IsCompleted && flag)
                {
                    IsCompleted = true;
                    OnComplete?.Invoke(this);
                }
            }
            /// <summary>
            /// 注销当前成就
            /// </summary>
            public void Cancel()
            {
                IsCompleted = false;
                OnCancel?.Invoke(this);
                foreach (ModAchievementCondition c in _conditions.Values)
                {
                    c.Cancel();
                }
            }
            /// <summary>
            /// 当其他Mod试图访问时，将询问你的许可
            /// 如果返回false，访问者将得到null
            /// 默认拒绝
            /// </summary>
            /// <param name="mod"></param>
            /// <returns></returns>
            public virtual bool CanAccess(Mod mod)
            {
                return false;
            }
            /// <summary>
            /// 枚举绘制对象
            /// </summary>
            public enum UseEffectDrawTarget
            {
                /// <summary>
                /// 顶部面板
                /// </summary>
                PanelTop,
                /// <summary>
                /// 成就类型图标
                /// </summary>
                Category,
                /// <summary>
                /// 名字文字
                /// </summary>
                Name,
                /// <summary>
                /// 描述文字
                /// </summary>
                Description,
                /// <summary>
                /// 底部面板
                /// </summary>
                PanelBottom,
                /// <summary>
                /// 进度条
                /// </summary>
                Progress,
                /// <summary>
                /// 进度条信息
                /// </summary>
                ProgressInfo,
                /// <summary>
                /// 成就图标
                /// </summary>
                Icon,
                /// <summary>
                /// 成就边框
                /// </summary>
                Borders
            }
        }
        /// <summary>
        /// 给ModAchievement添加完成条件
        /// </summary>
        public abstract class ModAchievementCondition
        {
            internal void InnerSetDefaults(Mod mod, string name)
            {
                Mod = mod;
                Name = name;
                OnComplete += CallOwner;
                SetDefaults();
            }
            /// <summary>
            /// 不解释，爬
            /// </summary>
            public virtual void SetDefaults()
            {

            }
            /// <summary>
            /// 这个条件从属的模组
            /// </summary>
            public Mod Mod;
            /// <summary>
            /// 标识名
            /// </summary>
            public string Name { get; private set; }
            internal string InnerName => Mod.Name + "_" + Name;
            /// <summary>
            /// 以ModAchievementCondition为参数的void委托
            /// </summary>
            /// <param name="condition"></param>
            public delegate void MACEvent(ModAchievementCondition condition);
            /// <summary>
            /// 当条件完成时触发
            /// </summary>
            public event MACEvent OnComplete;
            /// <summary>
            /// 当完成情况被注销时触发
            /// </summary>
            public event MACEvent OnCancel;
            /// <summary>
            /// 指示这个条件是否完成
            /// </summary>
            public bool IsCompleted;
            /// <summary>
            /// 标记这个条件完成了
            /// </summary>
            public void Complete()
            {
                IsCompleted = true;
                OnComplete?.Invoke(this);
            }
            /// <summary>
            /// 注销这个条件的完成情况
            /// </summary>
            public void Cancel()
            {
                IsCompleted = false;
                OnCancel?.Invoke(this);
            }
            internal static void CallOwner(ModAchievementCondition modAchievementCondition)
            {
                modAchievementCondition.Mod.Call(new object[] { ModderDLL.Instance, "ModAchievementCondistionCompleted", modAchievementCondition });
            }
            /// <summary>
            /// 当其他Mod试图访问时，将询问你的许可
            /// 如果返回false，访问者将得到null
            /// 默认拒绝
            /// </summary>
            /// <param name="mod"></param>
            /// <returns></returns>
            public virtual bool CanAccess(Mod mod)
            {
                return false;
            }
        }
        internal class UIModAchievementListItem : UIAchievementListItem
        {
            internal UIModAchievementListItem(Achievement achievement, bool large) : base(achievement, large)
            {
                var method = ModContent.GetInstance<AchievementMethod>();
                modAchievement = method.achievements[achievement.Name];
                this.large = large;
                BackgroundColor = modAchievement.GetBackgroundColor(-1, false);
                BorderColor = modAchievement.GetBorderColor(-1, false);
                float num = 16 + large.ToInt() * 20;
                float num2 = large.ToInt() * 6;
                float num3 = large.ToInt() * 12;
                Height.Set(66f + num, 0f);
                Width.Set(0f, 1f);
                PaddingTop = 8f;
                PaddingLeft = 9f;
                oldachievementicon = modAchievement.GetAchievementIcon(-1, IsMouseHovering);
                achievementIcon = new ModAchievementIconFramed(this, oldachievementicon, modAchievement.GetAchievementIconFrame(-1, IsMouseHovering));
                achievementIcon.Left.Set(num2, 0f);
                achievementIcon.Top.Set(num3, 0f);
                Append(achievementIcon);
                achievementIconBorders = new ModAchievementBorders(this, modAchievement.GetAchievementIconBorders(-1, IsMouseHovering), modAchievement.GetAchievementIconBordersFrame(-1, IsMouseHovering));
                achievementIconBorders.Left.Set(num2 - 4, 0f);
                achievementIconBorders.Top.Set(num3 - 4, 0f);
                Append(achievementIconBorders);
            }
            private void Update()
            {
                var asset = modAchievement.GetAchievementIcon(tick, IsMouseHovering);
                if (asset != oldachievementicon)
                {
                    achievementIcon.SetImage(asset, modAchievement.GetAchievementIconFrame(-1, IsMouseHovering));
                    achievementIcon.Left.Set(large.ToInt() * 6, 0f);
                    achievementIcon.Top.Set(large.ToInt() * 12, 0f);
                    Append(achievementIcon);
                    oldachievementicon = asset;
                }
                asset = modAchievement.GetAchievementIconBorders(tick, IsMouseHovering);
                if (asset != oldborders)
                {
                    achievementIconBorders.SetImage(asset, modAchievement.GetAchievementIconBordersFrame(-1, IsMouseHovering));
                    achievementIconBorders.Left.Set(large.ToInt() * 6 - 4, 0f);
                    achievementIconBorders.Top.Set(large.ToInt() * 12 - 4, 0f);
                    Append(achievementIconBorders);
                    oldborders = asset;
                }
                achievementIcon.SetFrame(modAchievement.GetAchievementIconFrame(tick, IsMouseHovering));
                achievementIconBorders.SetFrame(modAchievement.GetAchievementIconBordersFrame(tick, IsMouseHovering));
            }
            protected override void DrawSelf(SpriteBatch spriteBatch)
            {
                tick++;
                base.DrawSelf(spriteBatch);
                int num = large.ToInt() * 6;
                Vector2 value = new(num, 0f);
                bool iscomplete = !modAchievement.IsCompleted;
                Update();
                CalculatedStyle innerDimensions = GetInnerDimensions();
                CalculatedStyle dimensions = achievementIconBorders.GetDimensions();
                float num2 = dimensions.X + dimensions.Width;
                Vector2 vector3 = new(num2 + 7f, innerDimensions.Y);
                Tuple<decimal, decimal> trackerValues = GetTrackerValues();
                bool flag = false;
                if ((!(trackerValues.Item1 == 0m) || !(trackerValues.Item2 == 0m)) && iscomplete)
                {
                    flag = true;
                }
                float num3 = innerDimensions.Width - dimensions.Width + 1f - num * 2;
                Vector2 baseScale = new(0.85f);
                Vector2 baseScale2 = new(0.92f);
                var Description = modAchievement.GetDescription(tick, IsMouseHovering);
                string d = "";
                foreach (var des in Description)
                {
                    d += des.TextOriginal;
                }
                string text = FontAssets.ItemStack.Value.CreateWrappedText(d, (num3 - 20f) * (1f / baseScale2.X), Language.ActiveCulture.CultureInfo);
                Vector2 stringSize = ChatManager.GetStringSize(FontAssets.ItemStack.Value, text, baseScale2, num3);
                if (!large)
                {
                    stringSize = ChatManager.GetStringSize(FontAssets.ItemStack.Value,
                        Description,
                        baseScale2,
                        num3);
                }
                float num4 = 38f + (large ? 20 : 0);
                if (stringSize.Y > num4)
                {
                    baseScale2.Y *= num4 / stringSize.Y;
                }
                Vector2 vector = vector3 - Vector2.UnitY * 2f + value;
                bool useeffect;
                if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.PanelTop, tick, IsMouseHovering))
                {
                    useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.PanelTop, tick, IsMouseHovering);
                    DrawPanelTop(spriteBatch,
                        vector,
                        num3,
                        modAchievement.GetPanenlBaseColor(tick, IsMouseHovering, true));
                    if (useeffect)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.PanelTop, tick, IsMouseHovering);
                AchievementCategory category = modAchievement.Category;
                vector.Y += 2f;
                vector.X += 4f;
                if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.Category, tick, IsMouseHovering))
                {
                    useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.Category, tick, IsMouseHovering);
                    var _categoryTexture = modAchievement.GetCategoryTexture(tick, IsMouseHovering);
                    if (_categoryTexture is null)
                    {
                        _categoryTexture = Main.Assets.Request<Texture2D>("Images/UI/Achievement_Categories");
                        spriteBatch.Draw(_categoryTexture.Value,
                            vector,
                            new Rectangle?(_categoryTexture.Frame(4, 2, (int)category, 0, 0, 0)),
                            IsMouseHovering ? Color.White : Color.Silver,
                            0f,
                            Vector2.Zero, 0.5f, 0, 0f);
                    }
                    else
                    {
                        spriteBatch.Draw(_categoryTexture.Value,
                            vector,
                            null,
                            IsMouseHovering ? Color.White : Color.Silver,
                            0f,
                            Vector2.Zero, 0.5f, 0, 0f);
                    }
                    if (useeffect)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.Category, tick, IsMouseHovering);
                vector.X += 4f;
                vector.X += 17f;
                List<TextSnippet> name = new() { new($"[{modAchievement.Mod.Name}]") };
                name.AddRange(modAchievement.GetName(tick, IsMouseHovering));
                if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.Name, tick, IsMouseHovering))
                {
                    useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.Name, tick, IsMouseHovering);
                    ChatManager.DrawColorCodedString(spriteBatch,
                        FontAssets.ItemStack.Value,
                        name.ToArray(),
                        vector,
                        modAchievement.GetNameBaseColor(tick, IsMouseHovering),
                        0,
                        Vector2.Zero,
                        baseScale,
                        out int hoveredSnippet,
                        num3,
                        false);
                    if (useeffect)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.Name, tick, IsMouseHovering);
                vector.X -= 17f;
                Vector2 position = vector3 + Vector2.UnitY * 27f + value;
                if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.PanelBottom, tick, IsMouseHovering))
                {
                    useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.PanelBottom, tick, IsMouseHovering);
                    DrawPanelBottom(spriteBatch,
                        position,
                        num3,
                        modAchievement.GetPanenlBaseColor(tick, IsMouseHovering, false));
                    if (useeffect)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.PanelBottom, tick, IsMouseHovering);
                position.X += 8f;
                position.Y += 4f;
                if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.Description, tick, IsMouseHovering))
                {
                    useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.Description, tick, IsMouseHovering);
                    ChatManager.DrawColorCodedString(spriteBatch,
                        FontAssets.ItemStack.Value,
                        Description,
                        position,
                        modAchievement.GetDescriptionBaseColor(tick, IsMouseHovering),
                        0,
                        Vector2.Zero,
                        baseScale,
                        out int hoveredSnippet,
                        num3,
                        false);
                    if (useeffect)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.Description, tick, IsMouseHovering);
                if (flag)
                {
                    Vector2 vector2 = vector + Vector2.UnitX * num3 + Vector2.UnitY;
                    string text2 = ((int)trackerValues.Item1).ToString() + "/" + ((int)trackerValues.Item2).ToString();
                    Vector2 baseScale3 = new(0.75f);
                    Vector2 stringSize2 = ChatManager.GetStringSize(FontAssets.ItemStack.Value, text2, baseScale3, -1f);
                    float progress = (float)(trackerValues.Item1 / trackerValues.Item2);
                    float num5 = 80f;
                    Color color2 = new(100, 255, 100);
                    if (!IsMouseHovering)
                    {
                        color2 = Color.Lerp(color2, Color.Black, 0.25f);
                    }
                    Color color3 = new(255, 255, 255);
                    if (!IsMouseHovering)
                    {
                        color3 = Color.Lerp(color3, Color.Black, 0.25f);
                    }
                    if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.Progress, tick, IsMouseHovering))
                    {
                        useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.Progress, tick, IsMouseHovering);
                        DrawProgressBar(spriteBatch, progress, vector2 - Vector2.UnitX * num5 * 0.7f, num5, color3, color2, color2.MultiplyRGBA(new Color(new Vector4(1f, 1f, 1f, 0.5f))));
                        if (useeffect)
                        {
                            spriteBatch.End();
                            spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                        }
                    }
                    modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.Progress, tick, IsMouseHovering);
                    vector2.X -= num5 * 1.4f + stringSize2.X;
                    if (modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.ProgressInfo, tick, IsMouseHovering))
                    {
                        useeffect = modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.ProgressInfo, tick, IsMouseHovering);
                        ChatManager.DrawColorCodedStringWithShadow(spriteBatch, FontAssets.ItemStack.Value, text2, vector2, Color.White, 0f, new Vector2(0f, 0f), baseScale3, 90f, 2f);
                        if (useeffect)
                        {
                            spriteBatch.End();
                            spriteBatch.Begin(0, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                        }
                    }
                    modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.ProgressInfo, tick, IsMouseHovering);
                }
            }
            private void DrawPanelTop(SpriteBatch spriteBatch, Vector2 position, float width, Color color)
            {
                var texture = modAchievement.GetPanelTopTexture(tick, IsMouseHovering) ?? Main.Assets.Request<Texture2D>("Images/UI/Achievement_InnerPanelTop");
                spriteBatch.Draw(texture.Value, position, new Rectangle?(new Rectangle(0, 0, 2, texture.Height())), color);
                spriteBatch.Draw(texture.Value, new Vector2(position.X + 2f, position.Y), new Rectangle?(new Rectangle(2, 0, 2, texture.Height())), color, 0f, Vector2.Zero, new Vector2((width - 4f) / 2f, 1f), 0, 0f);
                spriteBatch.Draw(texture.Value, new Vector2(position.X + width - 2f, position.Y), new Rectangle?(new Rectangle(4, 0, 2, texture.Height())), color);
            }
            private void DrawPanelBottom(SpriteBatch spriteBatch, Vector2 position, float width, Color color)
            {
                var texture = modAchievement.GetPanelBottomTexture(tick, IsMouseHovering, large) ?? Main.Assets.Request<Texture2D>("Images/UI/Achievement_InnerPanelBottom" + (large ? "_Large" : ""));
                spriteBatch.Draw(texture.Value, position, new Rectangle?(new Rectangle(0, 0, 6, texture.Height())), color);
                spriteBatch.Draw(texture.Value, new Vector2(position.X + 6f, position.Y), new Rectangle?(new Rectangle(6, 0, 7, texture.Height())), color, 0f, Vector2.Zero, new Vector2((width - 12f) / 7f, 1f), 0, 0f);
                spriteBatch.Draw(texture.Value, new Vector2(position.X + width - 6f, position.Y), new Rectangle?(new Rectangle(13, 0, 6, texture.Height())), color);
            }
            public override void MouseOver(UIMouseEvent evt)
            {
                base.MouseOver(evt);
                BackgroundColor = modAchievement.GetBackgroundColor(tick, true);
                BorderColor = modAchievement.GetBorderColor(tick, true);
            }
            public override void MouseOut(UIMouseEvent evt)
            {
                base.MouseOut(evt);
                BackgroundColor = modAchievement.GetBackgroundColor(tick, false);
                BorderColor = modAchievement.GetBorderColor(tick, false);
            }
            private Tuple<decimal, decimal> GetTrackerValues()
            {
                if (modAchievement.Tracker is null || modAchievement.HideTracker)
                {
                    return Tuple.Create(0m, 0m);
                }
                IAchievementTracker tracker = modAchievement.Tracker;
                if (tracker.GetTrackerType() == TrackerType.Int)
                {
                    AchievementTracker<int> achievementTracker = (AchievementTracker<int>)tracker;
                    return Tuple.Create<decimal, decimal>(achievementTracker.Value, achievementTracker.MaxValue);
                }
                if (tracker.GetTrackerType() == TrackerType.Float)
                {
                    AchievementTracker<float> achievementTracker2 = (AchievementTracker<float>)tracker;
                    return Tuple.Create((decimal)achievementTracker2.Value, (decimal)achievementTracker2.MaxValue);
                }
                return modAchievement.GetCustomTrackerValue();
            }
            private static void DrawProgressBar(SpriteBatch spriteBatch, float progress, Vector2 spot, float Width = 169f, Color BackColor = default(Color), Color FillingColor = default, Color BlipColor = default)
            {
                if (BlipColor == Color.Transparent)
                {
                    BlipColor = new(255, 165, 0, 127);
                }
                if (FillingColor == Color.Transparent)
                {
                    FillingColor = new(255, 241, 51);
                }
                if (BackColor == Color.Transparent)
                {
                    FillingColor = new(255, 255, 255);
                }
                Texture2D value = TextureAssets.ColorBar.Value;
                Texture2D value3 = TextureAssets.ColorBlip.Value;
                Texture2D value2 = TextureAssets.MagicPixel.Value;
                float num = MathHelper.Clamp(progress, 0f, 1f);
                float num2 = Width * 1f;
                float num3 = 8f;
                float num4 = num2 / 169f;
                Vector2 position = spot + Vector2.UnitY * num3 + Vector2.UnitX * 1f;
                spriteBatch.Draw(value, spot, new Rectangle?(new Rectangle(5, 0, value.Width - 9, value.Height)), BackColor, 0f, new Vector2(84.5f, 0f), new Vector2(num4, 1f), 0, 0f);
                spriteBatch.Draw(value, spot + new Vector2((0f - num4) * 84.5f - 5f, 0f), new Rectangle?(new Rectangle(0, 0, 5, value.Height)), BackColor, 0f, Vector2.Zero, Vector2.One, 0, 0f);
                spriteBatch.Draw(value, spot + new Vector2(num4 * 84.5f, 0f), new Rectangle?(new Rectangle(value.Width - 4, 0, 4, value.Height)), BackColor, 0f, Vector2.Zero, Vector2.One, 0, 0f);
                position += Vector2.UnitX * (num - 0.5f) * num2;
                position.X -= 1f;
                spriteBatch.Draw(value2, position, new Rectangle?(new Rectangle(0, 0, 1, 1)), FillingColor, 0f, new Vector2(1f, 0.5f), new Vector2(num2 * num, num3), 0, 0f);
                if (progress != 0f)
                {
                    spriteBatch.Draw(value2, position, new Rectangle?(new Rectangle(0, 0, 1, 1)), BlipColor, 0f, new Vector2(1f, 0.5f), new Vector2(2f, num3), 0, 0f);
                }
                spriteBatch.Draw(value2, position, new Rectangle?(new Rectangle(0, 0, 1, 1)), Color.Black, 0f, new Vector2(0f, 0.5f), new Vector2(num2 * (1f - num), num3), 0, 0f);
            }
            internal readonly ModAchievement modAchievement;
            internal readonly bool large;
            internal UIImageFramed achievementIcon;
            internal UIImageFramed achievementIconBorders;
            internal int tick = 0;
            internal Asset<Texture2D> oldachievementicon, oldborders;
        }
        internal class ModAchievementIconFramed : UIImageFramed
        {
            public ModAchievementIconFramed(UIModAchievementListItem father, Asset<Texture2D> texture, Rectangle frame) : base(texture, frame)
            {
                _father = father;
            }
            internal readonly UIModAchievementListItem _father;
            public override void Draw(SpriteBatch spriteBatch)
            {
                if (_father.modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.Icon, _father.tick, IsMouseHovering))
                {
                    bool overflowHidden = OverflowHidden;
                    Rectangle scissorRectangle = spriteBatch.GraphicsDevice.ScissorRectangle;
                    SamplerState anisotropicClamp = SamplerState.AnisotropicClamp;
                    bool flag = _father.modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.Icon, _father.tick, IsMouseHovering);
                    DrawSelf(spriteBatch);
                    if (flag)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, anisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                    if (overflowHidden)
                    {
                        spriteBatch.End();
                        Rectangle adjustedClippingRectangle = Rectangle.Intersect(GetClippingRectangle(spriteBatch), spriteBatch.GraphicsDevice.ScissorRectangle);
                        spriteBatch.GraphicsDevice.RasterizerState = OverflowHiddenRasterizerState;
                        spriteBatch.GraphicsDevice.ScissorRectangle = adjustedClippingRectangle;
                        spriteBatch.Begin(0, BlendState.AlphaBlend, anisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                    DrawChildren(spriteBatch);
                    if (overflowHidden)
                    {
                        RasterizerState rasterizerState = spriteBatch.GraphicsDevice.RasterizerState;
                        spriteBatch.End();
                        spriteBatch.GraphicsDevice.ScissorRectangle = scissorRectangle;
                        spriteBatch.GraphicsDevice.RasterizerState = rasterizerState;
                        spriteBatch.Begin(0, BlendState.AlphaBlend, anisotropicClamp, DepthStencilState.None, rasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                _father.modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.Icon, _father.tick, IsMouseHovering);
            }
        }
        internal class ModAchievementBorders : UIImageFramed
        {
            public ModAchievementBorders(UIModAchievementListItem father, Asset<Texture2D> texture, Rectangle frame) : base(texture, frame)
            {
                _father = father;
            }
            internal readonly UIModAchievementListItem _father;
            public override void Draw(SpriteBatch spriteBatch)
            {
                if (_father.modAchievement.PreDraw(ModAchievement.UseEffectDrawTarget.Borders, _father.tick, IsMouseHovering))
                {
                    bool overflowHidden = OverflowHidden;
                    bool useImmediateMode = UseImmediateMode;
                    Rectangle scissorRectangle = spriteBatch.GraphicsDevice.ScissorRectangle;
                    SamplerState anisotropicClamp = SamplerState.AnisotropicClamp;
                    bool flag = _father.modAchievement.UseEffect(ModAchievement.UseEffectDrawTarget.Borders, _father.tick, IsMouseHovering);
                    DrawSelf(spriteBatch);
                    if (flag)
                    {
                        spriteBatch.End();
                        spriteBatch.Begin(0, BlendState.AlphaBlend, anisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                    if (overflowHidden)
                    {
                        spriteBatch.End();
                        Rectangle adjustedClippingRectangle = Rectangle.Intersect(GetClippingRectangle(spriteBatch), spriteBatch.GraphicsDevice.ScissorRectangle);
                        spriteBatch.GraphicsDevice.RasterizerState = OverflowHiddenRasterizerState;
                        spriteBatch.GraphicsDevice.ScissorRectangle = adjustedClippingRectangle;
                        spriteBatch.Begin(0, BlendState.AlphaBlend, anisotropicClamp, DepthStencilState.None, OverflowHiddenRasterizerState, null, Main.UIScaleMatrix);
                    }
                    DrawChildren(spriteBatch);
                    if (overflowHidden)
                    {
                        RasterizerState rasterizerState = spriteBatch.GraphicsDevice.RasterizerState;
                        spriteBatch.End();
                        spriteBatch.GraphicsDevice.ScissorRectangle = scissorRectangle;
                        spriteBatch.GraphicsDevice.RasterizerState = rasterizerState;
                        spriteBatch.Begin(0, BlendState.AlphaBlend, anisotropicClamp, DepthStencilState.None, rasterizerState, null, Main.UIScaleMatrix);
                    }
                }
                _father.modAchievement.PostDraw(ModAchievement.UseEffectDrawTarget.Borders, _father.tick, IsMouseHovering);
            }
        }
    }
}