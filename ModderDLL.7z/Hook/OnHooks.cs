﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoMod.RuntimeDetour.HookGen;
using ReLogic.Content;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Terraria.Achievements;
using Terraria.Audio;
using Terraria.GameContent.UI.Elements;
using Terraria.Localization;
using Terraria.UI;
using static ModderDLL.Advanced.AchievementMethod;

namespace ModderDLL.Hook
{
    internal class OnHooks
    {
        internal static void Load()
        {
            On_Achievement.Load();
            On.Terraria.UI.UIElement.OnActivate += UIElement_OnActivate;
        }
        internal static void Unload()
        {
            On_Achievement.Unload();
			On.Terraria.UI.UIElement.OnActivate -= UIElement_OnActivate;
		}
		private static void UIElement_OnActivate(On.Terraria.UI.UIElement.orig_OnActivate orig, UIElement self)
		{
			if (self.GetType().Name == "UIExtractMod")
			{
                if (!ModderDLL.CanUseAll)
                {
                    orig(self);
                    return;
                }
                object localmod = self
					.GetType()
						.GetField("mod", BindingFlags.Instance | BindingFlags.NonPublic)
							.GetValue(self);
				FieldInfo properties = localmod
					.GetType()
						.GetField("properties", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public);
				object obj_properties = properties.GetValue(localmod);
				obj_properties.GetType()
					.GetField("hideCode", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public)
						.SetValue(obj_properties, false); 
				obj_properties.GetType()
					.GetField("hideResources", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Public)
						.SetValue(obj_properties, false);
				properties.SetValue(localmod, obj_properties);
				self.GetType()
					.GetField("mod", BindingFlags.Instance | BindingFlags.NonPublic)
						.SetValue(self, localmod);
				orig(self);
			}
            else
            {
				orig(self);
            }
		}
		private class On_Achievement
        {
            internal static void Load()
            {
                On.Terraria.GameContent.UI.States.UIAchievementsMenu.InitializePage += UIAchievementsMenu_InitializePage;
                On.Terraria.GameContent.UI.Elements.UIList.SortMethod += UIList_SortMethod;
            }
            internal static void Unload()
            {
				On.Terraria.GameContent.UI.States.UIAchievementsMenu.InitializePage -= UIAchievementsMenu_InitializePage;
			}
			private static int UIList_SortMethod(On.Terraria.GameContent.UI.Elements.UIList.orig_SortMethod orig, UIList self, UIElement item1, UIElement item2)
			{
				if (item1 is UIAchievementListItem u11 && item2 is UIAchievementListItem u21)
				{
					int index1, index2;
					bool complete1, complete2;
					if (u11 is UIModAchievementListItem u12)
					{
						index1 = u12.modAchievement.Index;
						complete1 = u12.modAchievement.IsCompleted;
					}
					else
					{
						index1 = -1000 + u11.GetAchievement().Id;
						complete1 = u11.GetAchievement().IsCompleted;
					}
					if (u21 is UIModAchievementListItem u22)
					{
						index2 = u22.modAchievement.Index;
						complete2 = u22.modAchievement.IsCompleted;
					}
					else
					{
						index2 = -1000 + u21.GetAchievement().Id;
						complete2 = u21.GetAchievement().IsCompleted;
					}
					if (complete1 && !complete2)
					{
						return -1;
					}
					if (!complete1 && complete2)
					{
						return 1;
					}
					return index1.CompareTo(index2);
				}
				else
				{
					return orig(self, item1, item2);
				}
			}
            private static void UIAchievementsMenu_InitializePage(On.Terraria.GameContent.UI.States.UIAchievementsMenu.orig_InitializePage orig, Terraria.GameContent.UI.States.UIAchievementsMenu self)
            {
				self.RemoveAllChildren();
				Type type = self.GetType();
				BindingFlags flags = BindingFlags.NonPublic | BindingFlags.Instance;
				FieldInfo
					_categoryButtons = type.GetField("_categoryButtons", flags),
					_achievementElements = type.GetField("_achievementElements", flags),
					_achievementsList = type.GetField("_achievementsList", flags);
				List<UIToggleImage> categoryButtons = new();
				List<UIAchievementListItem> achievementElements = new();
				bool flag = true;
				int num = flag.ToInt() * 100;
				UIElement uIElement = new();
				uIElement.Width.Set(0f, 0.8f);
				uIElement.MaxWidth.Set(800f + (float)num, 0f);
				uIElement.MinWidth.Set(600f + (float)num, 0f);
				uIElement.Top.Set(220f, 0f);
				uIElement.Height.Set(-220f, 1f);
				uIElement.HAlign = 0.5f;
				type.GetField("_outerContainer", flags).SetValue(self, uIElement);
				self.Append(uIElement);
				UIPanel uIPanel = new();
				uIPanel.Width.Set(0f, 1f);
				uIPanel.Height.Set(-110f, 1f);
				uIPanel.BackgroundColor = new Color(33, 43, 79) * 0.8f;
				uIPanel.PaddingTop = 0f;
				uIElement.Append(uIPanel);
				UIList achievementsList = new();
				achievementsList.Width.Set(-25f, 1f);
				achievementsList.Height.Set(-50f, 1f);
				achievementsList.Top.Set(50f, 0f);
				achievementsList.ListPadding = 5f;
				uIPanel.Append(achievementsList);
                UITextPanel<LocalizedText> uITextPanel = new(Language.GetText("UI.Achievements"), 1f, true)
                {
                    HAlign = 0.5f
                };
                uITextPanel.Top.Set(-33f, 0f);
				uITextPanel.SetPadding(13f);
				uITextPanel.BackgroundColor = new Color(73, 94, 171);
				uIElement.Append(uITextPanel);
				UITextPanel<LocalizedText> uITextPanel2 = new UITextPanel<LocalizedText>(Language.GetText("UI.Back"), 0.7f, true);
				uITextPanel2.Width.Set(-10f, 0.5f);
				uITextPanel2.Height.Set(50f, 0f);
				uITextPanel2.VAlign = 1f;
				uITextPanel2.HAlign = 0.5f;
				uITextPanel2.Top.Set(-45f, 0f);
				uITextPanel2.OnMouseOver += FadedMouseOver;
				uITextPanel2.OnMouseOut += FadedMouseOut;
				uITextPanel2.OnClick += GoBackClick;
				uIElement.Append(uITextPanel2);
				type.GetField("_backpanel", flags).SetValue(self, uITextPanel2);
				foreach (var a in Main.Achievements.CreateAchievementsList())
				{
					UIAchievementListItem item = new(a, flag);
					achievementsList.Add(item);
					achievementElements.Add(item);
				}
				var method = ModContent.GetInstance<Advanced.AchievementMethod>();
				if (method is not null)
				{
					foreach (Advanced.AchievementMethod.ModAchievement a in method.achievements.Values)
					{
						Advanced.AchievementMethod.UIModAchievementListItem item = new(new(a.InnerName), flag);
						achievementsList.Add(item);
						achievementElements.Add(item);
					}
				}
				UIScrollbar uIScrollbar = new();
				uIScrollbar.SetView(100f, 1000f);
				uIScrollbar.Height.Set(-50f, 1f);
				uIScrollbar.Top.Set(50f, 0f);
				uIScrollbar.HAlign = 1f;
				uIPanel.Append(uIScrollbar);
				achievementsList.SetScrollbar(uIScrollbar);
				UIElement uIElement2 = new();
				uIElement2.Width.Set(0f, 1f);
				uIElement2.Height.Set(32f, 0f);
				uIElement2.Top.Set(10f, 0f);
				Asset<Texture2D> texture = Main.Assets.Request<Texture2D>("Images/UI/Achievement_Categories");
				for (int j = 0; j < 4; j++)
				{
					UIToggleImage uIToggleImage = new(texture, 32, 32, new Point(34 * j, 0), new Point(34 * j, 34));
					uIToggleImage.Left.Set(j * 36 + 8, 0f);
					uIToggleImage.SetState(true);
					uIToggleImage.OnClick += FilterList;
					categoryButtons.Add(uIToggleImage);
					uIElement2.Append(uIToggleImage);
				}
				uIPanel.Append(uIElement2);
				_categoryButtons.SetValue(self, categoryButtons);
				_achievementElements.SetValue(self, achievementElements);
				_achievementsList.SetValue(self, achievementsList);
			}
			private static void GoBackClick(UIMouseEvent evt, UIElement listeningElement)
			{
				Main.menuMode = 0;
				IngameFancyUI.Close();
			}
			private static void FadedMouseOver(UIMouseEvent evt, UIElement listeningElement)
			{
				SoundEngine.PlaySound(SoundID.MenuTick, new(-1, -1));
				((UIPanel)evt.Target).BackgroundColor = new Color(73, 94, 171);
				((UIPanel)evt.Target).BorderColor = Colors.FancyUIFatButtonMouseOver;
			}
			private static void FadedMouseOut(UIMouseEvent evt, UIElement listeningElement)
			{
				((UIPanel)evt.Target).BackgroundColor = new Color(63, 82, 151) * 0.8f;
				((UIPanel)evt.Target).BorderColor = Color.Black;
			}
			private static void FilterList(UIMouseEvent evt, UIElement listeningElement)
			{
				Main.AchievementsMenu.GetType().GetMethod("FilterList", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(Main.AchievementsMenu, new object[] { evt, listeningElement });
			}
		}
    }
}
